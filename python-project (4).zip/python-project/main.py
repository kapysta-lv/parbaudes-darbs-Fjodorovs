# ----------------------------------------------------------------------
# C1. Atzīmju kopsavilkums
# ----------------------------------------------------------------------

# Kodā izveido sarakstu ar septiņām atzīmēm. Izvadi to skaitu, summu, vidējo, augstāko un zemāko. Visu kodu raksti pats.
#
# Šis fails ir tukšs. Visu kodu raksti pats zem šīs rindas.
# ----------------------------------------------------------------------                                                                                                Sarakstu, kurā glabā atzīmes, nosauc ar vārdu atzimju_saraksts.

saraksts = [6, 9, 4, 2, 7, 5, 10]

skaits = len(saraksts)
summa = sum(saraksts)
vidējā = summa / skaits
augstākā = max(saraksts)
zemāk = min(saraksts)

print("skaits:", skaits)
print("summa:", summa)
print("vidējā:", vidējā)
print("augstākā:", augstākā)
print("zemāk:", zemāk)
