# ----------------------------------------------------------------------
# C2. Degviela un braucieni
# ----------------------------------------------------------------------

# Tvertnē ir 50 litri degvielas. Viens brauciens patērē 7 litrus. Izvadi, cik braucienu var veikt un cik degvielas paliek pāri. Visu kodu raksti pats.
#
# Šis fails ir tukšs. Visu kodu raksti pats zem šīs rindas.
# ----------------------------------------------------------------------                                                                                                Katru rezultāta rindu beidz ar punktu.

degviela = 50
paterins = 7

braucieni = degviela // paterins
atlikums = degviela % paterins

print("Var veikt", braucieni, "braucienus.")
print("Atlikums paliek", atlikums)
